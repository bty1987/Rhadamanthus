create
    definer = root@`%` function kv(m varchar(32), c varchar(32), t varchar(32), k varchar(32)) returns varchar(32)
    deterministic
begin

	declare response varchar(32) default '';

	set response = (select value from communion.constant where `module` = m and `clazz` = c and `type` = t and `key` = k and status = 0 limit 1);

	return response;
end;

